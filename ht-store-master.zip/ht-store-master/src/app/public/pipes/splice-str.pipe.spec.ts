import { SpliceStrPipe } from './splice-str.pipe';

describe('SpliceStrPipe', () => {
  it('create an instance', () => {
    const pipe = new SpliceStrPipe();
    expect(pipe).toBeTruthy();
  });
});
