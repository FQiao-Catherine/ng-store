import { ImgPreviewPipe } from './img-preview.pipe';

describe('ImgPreviewPipe', () => {
  it('create an instance', () => {
    const pipe = new ImgPreviewPipe();
    expect(pipe).toBeTruthy();
  });
});
