import { Level2AreaNamePipe } from './level-2-area-name.pipe';

describe('Level2AreaNamePipe', () => {
  it('create an instance', () => {
    const pipe = new Level2AreaNamePipe();
    expect(pipe).toBeTruthy();
  });
});
