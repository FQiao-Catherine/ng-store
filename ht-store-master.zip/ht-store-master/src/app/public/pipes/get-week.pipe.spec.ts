import { GetWeekPipe } from './get-week.pipe';

describe('GetWeekPipe', () => {
  it('create an instance', () => {
    const pipe = new GetWeekPipe();
    expect(pipe).toBeTruthy();
  });
});
