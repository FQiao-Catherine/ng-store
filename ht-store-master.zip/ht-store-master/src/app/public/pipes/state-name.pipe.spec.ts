import { StateNamePipe } from './state-name.pipe';

describe('StateNamePipe', () => {
  it('create an instance', () => {
    const pipe = new StateNamePipe();
    expect(pipe).toBeTruthy();
  });
});
