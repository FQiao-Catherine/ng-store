import { ImgSizePipe } from './img-size.pipe';

describe('MoneyPipe', () => {
  it('create an instance', () => {
    const pipe = new ImgSizePipe();
    expect(pipe).toBeTruthy();
  });
});
