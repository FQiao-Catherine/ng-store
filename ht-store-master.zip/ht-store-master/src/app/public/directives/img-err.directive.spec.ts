import { ImgErrDirective } from './img-err.directive';

describe('ImgErrDirective', () => {
  it('should create an instance', () => {
    const directive = new ImgErrDirective();
    expect(directive).toBeTruthy();
  });
});
